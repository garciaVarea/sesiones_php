<?php
session_start();
echo '<h2>Zona pública</h2>';
echo '<p>Ya sabemos que quieres visitar</p>';
echo $_SESSION['destino'];