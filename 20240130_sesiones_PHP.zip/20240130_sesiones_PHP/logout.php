<?php
echo '<h2>Logout</h2>';