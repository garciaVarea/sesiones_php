<html>

<body>
<?php
echo '<h2>Login de usuarios</h2>';
?>

<form method="post" action="login-action.php">
    <input type="email" name="correo">
    <input type="password" name="contraseña">
    <input type="submit" value="Acceder">
</form>

</body>
</html>
