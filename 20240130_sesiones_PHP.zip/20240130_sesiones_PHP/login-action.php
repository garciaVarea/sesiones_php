<?php
$correo=$_POST['correo'];
$contraseña=$_POST['contraseña'];

if($correo=='admin@gmail.com'){
    session_start();
    $_SESSION['usuario']=$correo;
    header('Location:privado.php');
}
else{
    echo '<p>Usuario no válido</p>';
    echo '<a href="registro.php">Alta de usuarios</a>';
}
