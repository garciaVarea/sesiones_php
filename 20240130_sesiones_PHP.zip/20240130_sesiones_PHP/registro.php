<html>

<body>
<h2>Alta de usuario</h2>
<form method="post" action="registro-action.php">
    <input type="email" name="correo">
    <input type="password" name="contraseña">
    <input type="submit" value="Crear usuario">
</form>
</body>
</html>