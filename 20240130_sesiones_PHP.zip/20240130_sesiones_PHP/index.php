<html>
<body>

<?php
echo '<h2>Página de inicio</h2>';
//header('Location:publica.php');
?>

<a href="privado.php">Zona privada</a>
<a href="publica.php">Zona pública</a>
</body>
</html>

